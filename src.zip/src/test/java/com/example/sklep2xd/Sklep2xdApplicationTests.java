package com.example.sklep2xd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sklep2xdApplicationTests {

	@Test
	void contextLoads() {
	}

}
