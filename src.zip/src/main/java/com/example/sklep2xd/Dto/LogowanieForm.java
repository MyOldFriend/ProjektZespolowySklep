package com.example.sklep2xd.Dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LogowanieForm {
    private String login;
    private String haslo;
    private String rodzajUzytkownika;
}
