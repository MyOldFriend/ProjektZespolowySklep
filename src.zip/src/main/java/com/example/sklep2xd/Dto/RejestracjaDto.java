package com.example.sklep2xd.Dto;

import lombok.Data;
import org.antlr.v4.runtime.misc.NotNull;
@Data
public class RejestracjaDto {

    private int id;

    private  String login;
    private  String haslo;
}
