package com.example.sklep2xd.Dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class KategoriaDto {
    private int idKategorii; // Zmieniono na idKategorii
    private String nazwaKategorii;


}
